Changelog can be found here: http://octobercms.com/changelog
